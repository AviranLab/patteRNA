from . import cli

cli.main()
