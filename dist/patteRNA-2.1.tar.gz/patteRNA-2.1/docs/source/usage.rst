Usage
=====

patteRNA has two positional arguments: 1) the file containing probing data and 2) a output path.

.. code-block:: console

    patteRNA <probing> <output> <OPTIONS>


All available options are accessible via `patteRNA -h` as listed below. Recommendations (when applicable) are given in the option caption. Note that switches (i.e. boolean options that do not need arguments), have defaults set to `False` and are set to `True` if provided.

.. code-block:: console

    usage: patteRNA [-h] [--version] [-f fasta] [--reference] [-v] [-l] [--GMM]
                    [-k] [--KL-div] [-e] [-i] [-nt] [--model] [--config] [--motif]
                    [--hairpins] [--posteriors] [--viterbi] [--HDSL] [--SPP]
                    [--nan] [--no-prompt] [--min-cscores] [--no-cscores]
                    [--batch-size]
                    probing output

    Rapid mining of RNA secondary structure motifs from profiling data.

    positional arguments:
      probing               FASTA-like file of probing data
      output                Output directory

    optional arguments:
      -h, --help            show this help message and exit
      --version             show program's version number and exit
      -f fasta, --fasta fasta
                            FASTA file of RNA sequences (default: None)
      --reference           FASTA-like file of reference RNA secondary structures
                            in dot-bracket notation (default: None)
      -v, --verbose         Print progress (default: False)
      -l, --log             Log transform input data (default: False)
      --GMM                 Train a Gaussian Mixture Model (GMM) during training
                            instead of a Discretized ObservationModel (DOM)
                            (default: False)
      -k                    Number of Gaussian components per pairing state in the
                            GMM model. By default, K is determined automatically
                            using Bayesian Information Criteria. If K <= 0,
                            automatic detection is enabled. Increasing K manually
                            will make the model fit the data tighter but could
                            result in overfitting. Fitted data should always be
                            visually inspected after training to gauge if the
                            model is adequate. (default: -1)
      --KL-div              Minimum Kullback–Leibler divergence criterion for
                            building the training set. The KL divergence measures
                            the difference in information content between the full
                            dataset and the training set. The smaller the value,
                            the more representative the training set will be with
                            respect to the full dataset. However, this will
                            produce a larger training set and increase both
                            runtime and RAM consumption during training. (default:
                            0.001)
      -e , --epsilon        Convergence criterion (default: 0.01)
      -i , --maxiter        Maximum number of training iterations (default: 250)
      -nt , --n-tasks       Number of parallel processes. By default all available
                            CPUs are used. (default: -1)
      --model               Trained .json model (version 2.0+ models only)
                            (default: None)
      --config
      --motif               Score target motif declared using an extended dot-
                            bracket notation. Paired and unpaired bases are
                            denoted using parentheses '()' and dots '.',
                            respectively. A stretch of consecutive characters is
                            declared using the format <char>{<from>, <to>}. Can be
                            used in conjunction with --mask to modify the expected
                            underlying sequence of pairing states. (default: None)
      --hairpins            Score a representative set of hairpins (stem lengths 4
                            to 15; loop lengths 3 to 10). Automatically enabled
                            when the --HDSL flag is used. This flag overrides any
                            motif syntaxes provided via --motif. (default: False)
      --posteriors          Output the posterior probabilities of pairing states
                            (i.e. the probability Trellis) (default: False)
      --viterbi             Output the most likely sequence of pairing states for
                            entire transcripts (i.e. Viterbi paths) (default:
                            False)
      --HDSL                Use scores a representative set of hairpins (stem
                            lengths 4 to 15; loop lengths 3 to 10) to quantify
                            structuredness across the input data. This flag
                            overrides any motif syntaxes provided via --motif and
                            also activates --posteriors. (default: False)
      --SPP                 Smoothed P(paired). Quantifies structuredness across
                            the input data via local pairing probabilities. This
                            flag activates --posteriors. (default: False)
      --nan                 If NaN are considered informative in term of pairing
                            state, use this flag. However, note that this can lead
                            to unstable results and is therefore not recommended
                            if data quality is low or long runs of NaN exist in
                            the data. (default: False)
      --no-prompt           Do not prompt a question if existing output files
                            could be overwritten. Useful for automation using
                            scripts or for running patteRNA on computing servers.
                            (default: False)
      --min-cscores         Minimum number of scores to sample during construction
                            of null distributions to usefor c-score normalization
                            (default: 1000)
      --no-cscores          Suppress the computation of c-scores during the
                            scoring phase (default: False)
      --batch-size          Number of transcripts to process at once using a pool
                            of parallel workers (default: 100)



Inputs
------

patteRNA uses a FASTA-like convention for probing data (see this [example file](sample_data/weeks_set.shape)). As patteRNA learns from data, non-normalized data can be used directly. Also, patteRNA fully supports negatives and zero values, even when applying a log-transformation to the data (via the `-l` flag). We recommend to **not** artificially set negative values to 0. Missing data values must be set to `nan`, `NA` or `-999`.

### Training a model on a new dataset

By default, patteRNA will learn its model from the data. Run an example training phase using the command:

```
patteRNA sample_data/weeks_set.shape sample_output -vl
```

> If you ran the test during installation, you will be prompted about overwriting files in the existing directory `test`. Answer `y`/`yes`. Note that in this example we run patteRNA in verbose-mode (`-v`) and we log transform (`-l`) the input data.

This command will generate an output folder `sample_output` in the current directory which contains:

- A log file: `<date>.log`
- Trained model: `trained_model.json`
- A plot of the fitted data: `fit.png`/`fit.svg`
- A plot of the model's log-likelihood convergence: `logL.png`/`logL.svg`

### Scoring
patteRNA supports structural motifs (via the `--motif` flag) that contain no gaps. These options can be used in conjunction with training to perform both training and scoring using a single command. However, we recommend to train patteRNA first and use the trained model in subsequent searches for motifs. Trained models are saved as `trained_model.json` and can be loaded using the flag `--model`.

#### Motif Specification
Standard motifs can be declared using an extended dot-bracket notation where stretches of consecutive repeats are denoted by curly brackets. For instance, an hairpin of stem size 4 and loop size 5 can be declared by `((((.....))))` (full form) or alternatively `({4}.{5}){4}` (short form). Curly brackets can also be used to indicate stretches of varying length using the convention `{<from>,<to>}`. For example, all loops of size 2 to 7 can be declared as `.{2,7}`. By default, RNA sequences are used to ensure a scored region sequence is compatible with the folding of the motif. RNA sequences must be provided in a FASTA file inputted using the option `-f <fasta-file>`. See [example commands](#examples).


#### Score Files
The results of a motif search are saved in the file `scores.txt` in the output directory. This file contains putative sites  the following columns:

- Transcript name
- Site start position (uses a 1-based encoding)
- Score
- C-score
- Motif in dot-bracket notation
- Nucleotide sequence

### Additional outputs
#### Viterbi path
patteRNA can return the most likely sequence of pairing states across an entire transcript, called the Viterbi path, using the `--viterbi` flag. This will create a FASTA-like file called `viterbi.txt` in the output directory, with numerical pairing states encoded as 0/1 for unpaired/paired bases, respectively.

#### Posterior probabilities
The posterior probabilities of pairing states at each nucleotides can be requested using the flag `--posteriors`. This will output a FASTA-like file called `posteriors.txt` where the first and second lines (after the header) correspond to unpaired and paired probabilities, respectively.

#### Hairpin-derived structure level (HDSL)
HDSL is a measure of local structure that assists in converting patteRNA's predicted hairpins into a quantitative assenment of structuredness. This will output a FASTA-like file called `hdsl.txt` with HDSL profiles for all transcripts in the input data.

### Examples <a name="examples"></a>

* Train the model and search for any loop of length 5:

    ```
    patteRNA sample_data/weeks_set.shape example_outputs/loop -vl --motif ".{5}" -f sample_data/weeks_set.fa
    ```

* Search for all loops of length 5 using a trained model:

    ```
    patteRNA sample_data/weeks_set.shape example_outputs/loop_pretrained -vl --model test/trained_model.json --motif ".{5}" -f sample_data/weeks_set.fa
    ```

* Search for hairpins of variable stem size 4 to 6 and loop size 5:

    ```
    patteRNA sample_data/weeks_set.shape example_outputs/hairpin -vl --model test/trained_model.json -f sample_data/weeks_set.fa --motif "({4,6}.{5}){4,6}"
    ```


* Request HDSL profiles and the posterior state probabilities using a trained model:

    ```
    patteRNA sample_data/weeks_set.shape example_outputs/hdsl -vl --model test/trained_model.json --HDSL
    ```

* Train the model using a set of reference transcripts:

    ```
    patteRNA sample_data/weeks_set.shape example_outputs/loop -vl -f sample_data/weeks_set.fa --reference sample_data/weeks_set.dot
    ```
