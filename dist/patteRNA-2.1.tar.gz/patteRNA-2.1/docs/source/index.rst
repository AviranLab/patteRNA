.. patteRNA documentation master file, created by
   sphinx-quickstart on Sun Aug 29 17:27:40 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

patteRNA
====================================


Contents
--------

.. toctree::
    installation
    usage
    examples


